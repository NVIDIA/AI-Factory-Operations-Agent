# AI Factory Operations Agent Security Model

AI Factory Operations Agent separates observation from mutation at the tool, credential, and session layers. Model instructions improve tool selection, but they are not a security boundary.

## Deployment Default

`modules.edit.enabled` defaults to `false`. The default deployment exposes read-only Kubernetes and Base Command Manager tools and does not install the edit Kubernetes credential, Base Command Manager admin tool, or remote SSH tool.

When the Edit module is enabled, every new interactive conversation still starts in View mode. Access is selected per conversation:

| Mode | Read-only tools | Sandbox execution and remote diagnostics | Infrastructure mutations |
| --- | --- | --- | --- |
| View | Automatic | Automatic | Blocked |
| Edit | Automatic | Automatic | Requires approval when `modules.edit.hitl=true` |
| Auto | Automatic | Automatic | Runs without approval after the user accepts the warning |

Automated alert and cluster-health sessions are always View-only. They cannot be changed to Edit or Auto.

For native Slack, `openclaw.slack.allowedUserIds` remains the messaging allowlist for DMs, group DMs, and channel mentions. `openclaw.slack.editUserIds` is narrower: those verified users receive Edit and approve their own mutations through Slack buttons; every other allowed Slack user remains in View.

Setting `modules.edit.hitl=false` also removes approvals from Edit mode. Keep the default `true` unless every user permitted to select Edit is trusted to make changes directly.

## Kubernetes Boundaries

Read and write operations use separate tools and Kubernetes credentials:

- `run_kubectl` uses the chart's read-only ServiceAccount. Its ClusterRole grants `get`, `list`, and `watch` for the supported operational resources. The tool rejects Secrets, interactive access, credential overrides, and shell syntax.
- `run_kubectl_admin` is installed only when Kubernetes editing is enabled. It accepts exact kubectl argv and optional standard input, executes without a local shell, requires approval in Edit, and skips approval in Auto. It accepts `--kubeconfig PATH` and `--kubeconfig=PATH` for a file available in the gateway container. The selected kubeconfig supplies the connection settings instead of the registered cluster defaults. Other credential override flags remain blocked. Its optional `host` field targets an installer-configured SSH host instead of the gateway; the kubeconfig stays on that host. Host and cluster are mutually exclusive. The existing SSH identity, host verification, argument validation, timeouts, and output limits apply, and Edit retains approval while Auto skips it.
- Its default ClusterRole permits `create`, `delete`, `patch`, and `update` for ConfigMaps, Pods, Services, Deployments, DaemonSets, StatefulSets, Jobs, and CronJobs, plus `create` on `pods/exec`. An operator can replace that role through `modules.edit.kubernetes.existingClusterRole` to define the actual administrative scope.

Kubernetes RBAC remains authoritative in every mode. Auto bypasses approval, not RBAC or request validation.

In Edit and Auto, authorized operations using files on a configured SSH host can execute through `run_remote_ssh`, including kubectl with a host-local kubeconfig. The existing SSH host restrictions and approval policy apply. This execution path uses credentials in place and does not require registering the same cluster with the gateway Kubernetes tool. Policy denials still cannot be bypassed through another tool.

## Base Command Manager Boundaries

The read-only and administrative Base Command Manager paths use separate identities and tools:

- `bcm_execute_cmsh` uses the dedicated Base Command Manager read-only identity and never requests approval.
- `bcm_execute_cmsh_admin`, `bcm_add_note`, and `bcm_remove_note` are installed only when Base Command Manager editing is enabled. They are blocked in View, approval-gated in Edit, and automatic in Auto.

Base Command Manager's configured profile remains authoritative. Enabling Base Command Manager administration requires an operator-provided credential with the intended cluster permissions.

When `modules.bcm.redfish.enabled=true`, the `bcm_redfish_*` tools read node BMCs in every mode, including View and automated sessions. They are never mutation tools. The model supplies only a Base Command Manager hostname and a path or named query. The Base Command Manager adapter resolves the BMC address and credentials through CMSH and does not return them. Its `RedfishPolicy` allowlist is enforced server-side before any credential lookup, and again on every resource embedded in a response, so `$expand` cannot reach a denied resource. It permits only `GET` on inventory, health, sensor, log, firmware, and task resources, and rejects any path containing `Actions`, as well as account, session, certificate, event, Secure Boot, BIOS settings, and virtual media resources. Responses have password, token, and secret fields redacted, and errors omit the BMC address. Like other read-only tools, Redfish is not a confidentiality boundary: anything the allowlist permits is visible to the session.

## Diagnostic Commands And SSH

Local `exec` runs inside the per-session OpenShell sandbox in View, Edit, Auto, and automated sessions. OpenShell enforces this boundary; the session guard does not parse or allowlist sandbox commands.

View mode can run a bounded set of read-only diagnostic commands on configured hosts through `run_remote_ssh`. Its policy in `diagnostic-policy.ts` validates the executable and every argument. It covers common hardware, operating-system, networking, and Slurm inspection commands such as `nvidia-smi`, `ipmitool mc info`, `journalctl`, `squeue`, and `scontrol show`.

The remote diagnostic policy rejects executable paths, shell operators, quoting, redirection, command substitution, nested SSH, arbitrary programs, and known mutating flags. Remote commands outside this policy are blocked in View and use Edit or Auto handling when available.

Remote SSH has additional constraints:

- Hosts are installer-defined aliases; the model cannot supply a destination.
- User, port, private key, and known-hosts data come from the Helm configuration and Secret.
- SSH option and identity overrides are not accepted.
- The remote command is transported as validated argv, not an arbitrary shell program.

Read-only execution is not a confidentiality boundary. A diagnostic command can read anything allowed by its operating-system or SSH identity. Operators must provision least-privilege identities and limit enrolled hosts accordingly.

## Approval And Auto

With `modules.edit.hitl=true`, Edit-mode mutations pause before execution and expose the exact operation to the user. Denial, expiration, or an unavailable approval service fails closed. Approval is scoped to one operation and does not change the conversation mode.

Auto presents a warning before activation, then executes the same validated mutation tools without approval. The warning is a user acknowledgement, not the enforcement mechanism. Server-side session state, tool validators, Kubernetes RBAC, Base Command Manager credentials, configured SSH hosts, and audit records continue to apply.

## Automation, Sandboxing, And Audit

- Scheduled cluster checks and alert-triggered sessions are marked as automation and reject all mutating tools regardless of requested mode.
- General local command execution remains inside OpenShell in every mode and is not subject to the remote diagnostic allowlist.
- Tool calls, approvals, denials, and results are recorded in the audit stream.
- Secrets remain Kubernetes Secrets and are mounted only into the workloads that need them. They are not supplied through prompts or committed values.

## Operator Responsibility

Enabling Edit expands the assistant's authority. Before enabling it, review the generated RBAC, any custom ClusterRole, Base Command Manager profiles, SSH host list, mounted credentials, and who can access the UI. Auto should be restricted to users trusted to exercise those configured permissions without per-operation review.

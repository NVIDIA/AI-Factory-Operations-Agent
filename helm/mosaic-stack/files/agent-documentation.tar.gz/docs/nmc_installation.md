# NMC Installation

This guide installs AI Factory Operations Agent on an NVIDIA Mission Control admin cluster. For upgrades, verification, LLM configuration, module reference, UI access, and headless usage, see the [shared Helm guide](installation.md).

For self-hosted inference on the separate GPU workload cluster, first follow [Self-hosted inference](#self-hosted-inference), then use its endpoint, served model name, and API key below. The bundled vLLM profile requires GPUs in the same cluster as the agent and should not be used on a GPU-free admin cluster.

## Execution environment

Run the NMC examples on the Base Command Manager head node in a Bash login shell. They assume a root login, which can read `/root/.ssh/id_ecdsa` and load the cluster administrator modules. From a sudo-enabled account, enter that shell **before** setting credentials:

```bash
sudo -i
```

Run the commands in the same Bash login shell as root or a user with Kubernetes administrator access and a readable SSH key specified by `CLUSTER_MANAGER_SSH_KEY_PATH`.

Both the agent and standalone inference charts are pulled from NGC. The commands work from any directory and do not require Git or a repository checkout. Each `module load` selects a different Kubernetes cluster for subsequent commands in that shell.

## Install the agent

Run this flow as a Kubernetes administrator on the Base Command Manager head node after setting `NGC_API_KEY`, `EXTERNAL_LLM_API_KEY`, `EXTERNAL_LLM_BASE_URL`, and `EXTERNAL_LLM_MODEL`. The endpoint, model, and API key must belong to the same OpenAI-compatible provider. For OpenAI, use `https://api.openai.com/v1` and a model available to that account.

Use an NGC account invited to the `afoa-release` team. Accept the invitation while signed in with that account, then create a personal API key with the Private Registry service in [NGC Setup > API Keys](https://org.ngc.nvidia.com/setup/api-keys). Save the key when shown; NGC displays it only once. Run the installation in a login shell with `module load` available.

The command selects the NMC `k8s-admin` cluster, connects AI Factory Operations Agent to the existing `kube-prometheus-stack` services, enables Slurm through Base Command Manager, and installs the AgentSandbox CRD and controller from the chart.

The namespace setup below appends the agent namespace to `admin.namespaceList` in the existing NMC network-policy release. This enables ingress and egress between agent pods and pods in NMC's listed platform namespaces, across all ports and protocols. It preserves the existing namespace list and other Helm values, and creates no additional policy release. This platform-admin option is broader than DNS-only access; site-specific policies can instead provide the required connections.

For this policy update, set `NMC_POLICY_CHART` to the local `nmc-network-policies` chart archive for the **same version already installed**, using your existing NMC bundle or chart artifact. See the [NMC network-policy installation guide](https://docs.nvidia.com/mission-control/docs/nmc-software-installation-guide/2.3.1/nmc-kube-security-guide.html#deploying-network-policies-with-helm-nmc-network-policies). The example uses release `net-pol` in namespace `default`; set `NMC_POLICY_RELEASE` and `NMC_POLICY_NAMESPACE` if your installation uses other names. The command requires `jq` and an existing NMC policy release. Leave `NMC_POLICY_CHART` unset on clusters without that release or where site-managed policies already provide the required access.

```bash
set -euo pipefail
module load kubernetes/k8s-admin

: "${NGC_API_KEY:?Set NGC_API_KEY to an NGC API key with private registry access}"
: "${EXTERNAL_LLM_API_KEY:?Set EXTERNAL_LLM_API_KEY for the selected provider}"
: "${EXTERNAL_LLM_BASE_URL:?Set EXTERNAL_LLM_BASE_URL for the selected provider}"
: "${EXTERNAL_LLM_MODEL:?Set EXTERNAL_LLM_MODEL for the selected provider}"
MOSAIC_NAMESPACE=${MOSAIC_NAMESPACE:-aifoa}
NMC_POLICY_RELEASE=${NMC_POLICY_RELEASE:-net-pol}
NMC_POLICY_NAMESPACE=${NMC_POLICY_NAMESPACE:-default}
MOSAIC_CHART=oci://nvcr.io/0948643769302270/afoa-release/mosaic-stack
CLUSTER_MANAGER_HEAD_HOST=${CLUSTER_MANAGER_HEAD_HOST:-$(hostname -s)}
CLUSTER_MANAGER_SSH_KEY_PATH=${CLUSTER_MANAGER_SSH_KEY_PATH:-/root/.ssh/id_ecdsa}

test -r "$CLUSTER_MANAGER_SSH_KEY_PATH"
kubectl cluster-info >/dev/null
kubectl auth can-i create deployments -n "$MOSAIC_NAMESPACE" | grep -qx yes
kubectl -n prometheus get secret kube-prometheus-stack-grafana >/dev/null
cmsh -c 'wlm; list' | grep -qi slurm

printf '%s' "$NGC_API_KEY" | helm registry login nvcr.io \
  --username '$oauthtoken' \
  --password-stdin

kubectl create namespace "$MOSAIC_NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -
if [[ -n ${NMC_POLICY_CHART:-} ]]; then
  test -r "$NMC_POLICY_CHART"
  command -v jq >/dev/null
  NMC_NAMESPACE_LIST=$(helm get values "$NMC_POLICY_RELEASE" \
    --namespace "$NMC_POLICY_NAMESPACE" --all -o json | \
    jq -ce --arg namespace "$MOSAIC_NAMESPACE" \
      '.admin.namespaceList | arrays | . + [$namespace] | unique')
  helm upgrade "$NMC_POLICY_RELEASE" "$NMC_POLICY_CHART" \
    --namespace "$NMC_POLICY_NAMESPACE" \
    --reuse-values \
    --set-json "admin.namespaceList=$NMC_NAMESPACE_LIST" \
    --wait
fi

kubectl -n "$MOSAIC_NAMESPACE" create secret generic mosaic-external-llm \
  --from-literal=apiKey="$EXTERNAL_LLM_API_KEY" \
  --dry-run=client -o yaml | kubectl apply -f -
kubectl -n "$MOSAIC_NAMESPACE" create secret generic bcm-host-ssh-key \
  --from-file=id_ecdsa="$CLUSTER_MANAGER_SSH_KEY_PATH" \
  --dry-run=client -o yaml | kubectl apply -f -

GRAFANA_USERNAME=$(kubectl -n prometheus get secret kube-prometheus-stack-grafana -o jsonpath='{.data.admin-user}' | base64 -d)
GRAFANA_PASSWORD=$(kubectl -n prometheus get secret kube-prometheus-stack-grafana -o jsonpath='{.data.admin-password}' | base64 -d)
kubectl -n "$MOSAIC_NAMESPACE" create secret generic mosaic-grafana-auth \
  --from-literal=username="$GRAFANA_USERNAME" \
  --from-literal=password="$GRAFANA_PASSWORD" \
  --dry-run=client -o yaml | kubectl apply -f -

# Remove --devel for the latest stable release, or replace it with --version 0.0.1 to pin that release.
helm upgrade --install aifoa "$MOSAIC_CHART" \
  --devel \
  -n "$MOSAIC_NAMESPACE" \
  --create-namespace \
  --set global.registryCredentials.create=true \
  --set-string global.registryCredentials.password="$NGC_API_KEY" \
  --set-json 'namespace.labels={"zarf.dev/agent":"ignore"}' \
  --set llm.mode=external \
  --set-string llm.external.baseUrl="$EXTERNAL_LLM_BASE_URL" \
  --set-string llm.external.model="$EXTERNAL_LLM_MODEL" \
  --set llm.external.existingSecret=mosaic-external-llm \
  --set observability.prometheusUrl=http://kube-prometheus-stack-prometheus.prometheus.svc.cluster.local:9090 \
  --set observability.grafanaUrl=http://kube-prometheus-stack-grafana.prometheus.svc.cluster.local/grafana \
  --set observability.grafanaDatasourceUid=prometheus \
  --set observability.grafanaAuth.existingSecret=mosaic-grafana-auth \
  --set modules.bcm.enabled=true \
  --set bcmMcp.enabled=true \
  --set bcmMcp.mode=ssh-adapter \
  --set-string bcmMcp.headHost="$CLUSTER_MANAGER_HEAD_HOST" \
  --set bcmMcp.hostSshKeySecretName=bcm-host-ssh-key \
  --set modules.slurm.enabled=true \
  --set modules.slurm.backend=auto \
  --reset-values \
  --wait \
  --timeout 12m
```

The command is a complete declaration and can be rerun unchanged. The SSH private key remains in the `bcm-host-ssh-key` Kubernetes Secret and is mounted only into the Base Command Manager adapter pod. On the first generic Base Command Manager MCP request, the adapter installs its matching remote server version on the Base Command Manager head automatically. With both modules enabled, the Slurm skill selects Base Command Manager WLM access instead of host-mounted vanilla evidence.

Web search is enabled by default and uses DuckDuckGo without an API key, so the admin cluster must allow HTTPS egress from the `openclaw` pod to `duckduckgo.com`. On air-gapped NMC installations, add `--set modules.webSearch.enabled=false` to the command above. To use Brave Search or turn web search off later, see [Web search](installation.md#web-search).

Before following the shared upgrade workflow in a new shell, run `module load kubernetes/k8s-admin` to select the NMC admin cluster.

<details>
<summary>Troubleshoot DNS or a Helm startup timeout</summary>

A successful lookup on the head node does not verify pod DNS. Agent pods need egress to CoreDNS, CoreDNS needs ingress from the agent namespace, and CoreDNS must reach its upstream DNS servers. HTTPS connectivity to the inference endpoint and startup download hosts is required separately.

For a customized cluster where DNS remains unavailable, inspect its DNS configuration:

```bash
module load kubernetes/k8s-admin
kubectl -n kube-system get pods -l k8s-app=kube-dns --show-labels
kubectl -n kube-system get service kube-dns
kubectl -n kube-system get endpointslices -l kubernetes.io/service-name=kube-dns
```

A rule selecting `app.kubernetes.io/name=coredns` does not match pods labeled only `k8s-app=kube-dns`. Confirm that the platform namespace allowlist includes the agent namespace. Have the platform administrator resolve any custom-policy or CoreDNS upstream-connectivity issues through the existing policy-management workflow.

If installation times out, check DNS from the running UI pod. If the UI is unavailable, use a diagnostic pod in the same namespace:

```bash
MOSAIC_NAMESPACE=${MOSAIC_NAMESPACE:-aifoa}
kubectl -n "$MOSAIC_NAMESPACE" exec deployment/mosaic-ui -- getent ahostsv4 kubernetes.default.svc.cluster.local
kubectl -n "$MOSAIC_NAMESPACE" exec deployment/mosaic-ui -- getent ahostsv4 dl.k8s.io
```

Both commands must return addresses. For `context deadline exceeded`, inspect the pods and failing container before retrying. In chart versions that download kubectl during startup, `curl: (6) Could not resolve host: dl.k8s.io` in `install-kubectl` indicates DNS failure:

```bash
kubectl -n "$MOSAIC_NAMESPACE" get pods
kubectl -n "$MOSAIC_NAMESPACE" logs deployment/openclaw -c install-kubectl --tail=30
```

After correcting DNS, the init container retries automatically. Verify that it completes and the OpenClaw deployment becomes available. This failure does not require changing the CoreDNS image or Corefile when CoreDNS already resolves names successfully.

</details>

## Self-hosted inference

Deploy inference in `k8s-user` and connect the agent in `k8s-admin` to its HTTPS endpoint. If you already have an OpenAI-compatible endpoint, skip to [Install the agent](#install-the-agent).

### 1. Configure inference

In the login shell described above, sign in to NGC using the same invited account described in [Install the agent](#install-the-agent). The standalone inference chart is published alongside the agent chart:

```bash
: "${NGC_API_KEY:?Set NGC_API_KEY to an NGC API key with private registry access}"
printf '%s' "$NGC_API_KEY" | helm registry login nvcr.io \
  --username '$oauthtoken' --password-stdin
INFERENCE_CHART=oci://nvcr.io/0948643769302270/afoa-release/afoa-inference
INFERENCE_CHART_VERSION=0.0.2-main.20261030003406.gd14c5492
```

This pins a published development version. Select another published version deliberately when upgrading. No checkout or `cd` step is needed. You need:

- A compatible GPU in `k8s-user`, the NVIDIA device plugin and a GPU runtime. The default [Nemotron 3.5 Super VL profile](https://huggingface.co/nvidia/NVIDIA-Nemotron-3.5-Super-VL-120B-A12B-NVFP4) requests one GPU, 8 CPUs, 64 GiB host memory and a 500 GiB persistent cache. Check the model card for GPU memory and driver requirements.
- A StorageClass for the cache, plus access to the vLLM image and model weights.
- An internal ingress controller, DNS name and TLS Secret. Admin-cluster pods must be able to reach that hostname on port 443 and trust its certificate.

Create `inference-values.yaml`, replacing these placeholders:

```yaml
ingress:
  enabled: true
  className: nginx
  host: inference.example.com
  tlsSecretName: inference-tls
```

The chart also includes a Qwen single-B200 profile. To select it, unpack the chart at the chosen version:

```bash
INFERENCE_CHART_WORKDIR=$(mktemp -d)
helm pull "$INFERENCE_CHART" --version "$INFERENCE_CHART_VERSION" \
  --untar --untardir "$INFERENCE_CHART_WORKDIR"
```

Use `"$INFERENCE_CHART_WORKDIR/afoa-inference"` as the install target, omit `--version`, and add `-f "$INFERENCE_CHART_WORKDIR/afoa-inference/profiles/qwen-1gpu.yaml"` before site values. See [Qwen hardware and reasoning requirements](installation.md#on-prem-inference). These profiles require a chart version containing them; the older pinned example above contains only Nemotron.

### 2. Deploy in `k8s-user`

Choose an inference API key and save it in your credential store. This same key will be used by the agent; it is separate from NGC and model-download credentials.

```bash
module load kubernetes/k8s-user
read -rsp 'Self-hosted inference API key: ' EXTERNAL_LLM_API_KEY; echo
kubectl create namespace afoa-inference --dry-run=client -o yaml | kubectl apply -f -
kubectl -n afoa-inference create secret generic afoa-inference-auth \
  --from-literal=apiKey="$EXTERNAL_LLM_API_KEY" \
  --dry-run=client -o yaml | kubectl apply -f -

helm upgrade --install afoa-inference "$INFERENCE_CHART" \
  --version "$INFERENCE_CHART_VERSION" \
  -n afoa-inference \
  -f inference-values.yaml \
  --wait \
  --timeout 2h
```

The default is Nemotron 3.5 Super VL NVFP4, validated on one B200 for text generation and automatic tool calling. The model revision and compatible vLLM image are pinned. GPU memory and architecture matter; one GPU does not mean every GPU is compatible.

When upgrading from Nemotron 3 Super, preserve site settings and cache size, and update existing clients to the served name `nemotron-3.5-super-vl`. For shared endpoints, validate a separate inference release before switching clients.

The first download and GPU kernel compilation can take more than 30 minutes. Wait for Helm to finish; startup checks are below.

### 3. Verify inference

Before installing the agent, test the HTTPS endpoint using the inference API key selected above; replace the example hostname and model if customized:

```bash
curl --fail-with-body --max-time 120 \
  "https://inference.example.com/v1/chat/completions" \
  -H "Authorization: Bearer $EXTERNAL_LLM_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "nemotron-3.5-super-vl",
    "messages": [{"role": "user", "content": "Reply with ready."}],
    "max_tokens": 128,
    "chat_template_kwargs": {"enable_thinking": false}
  }'
```

Confirm the response contains generated text in `choices[0].message.content`. This checks inference, authentication, DNS, TLS and ingress from the head node; the check below separately verifies access from the agent pod. If the request fails, inspect the startup and connectivity checks below before continuing.

### 4. Connect the agent

```bash
export EXTERNAL_LLM_BASE_URL='https://inference.example.com/v1'
export EXTERNAL_LLM_MODEL='nemotron-3.5-super-vl'
module load kubernetes/k8s-admin
```

Continue with [Install the agent](#install-the-agent), using the same inference key. `llm.mode=external` connects to your self-hosted endpoint. After installation, [open the UI](installation.md#usage) and send a short question.

Use the ingress hostname with `/v1`, rather than a cross-cluster `*.svc.cluster.local` address. If you changed `servedModelName`, use that name as `EXTERNAL_LLM_MODEL`. For an existing installation, use the provider-switch instructions below.

<details>
<summary>Site-specific GPU, storage and TLS settings</summary>

- Set `runtimeClassName` to your GPU runtime, or an empty string if the default runtime supports GPUs. Use `nodeSelector` for compatible hardware in a mixed cluster.
- Set `modelCache.storageClassName` for a non-default StorageClass. Keep cache size unchanged during upgrades: a normal Helm upgrade cannot resize the StatefulSet volume claim template.
- For restricted model downloads, set `modelToken.existingSecret`. Airgapped sites need an image mirror and a populated model cache.
- For a site CA, store its certificate in an admin-namespace Secret and set `llm.external.caCertificateSecret` on the agent chart (default key `ca.crt`; configurable with `caCertificateKey`). The agent and compatibility proxy add it to their normal trust stores. The inference chart does not create certificates or install an ingress controller; configure HTTPS redirects and streaming timeouts on your controller.
- In Run:ai-managed environments, ensure the target namespace has sufficient GPU quota.

The ingress exposes only `/v1`. Keep the backend Service on a trusted network because vLLM's API key does not protect every server endpoint. See [vLLM security guidance](https://docs.vllm.ai/en/latest/usage/security/).

See the [NMC Kubernetes installation guide](https://docs.nvidia.com/mission-control/docs/nmc-software-installation-guide/2.3.1/airgapped-installation/install-k8s.html) for cluster setup. Confirm your site's GPU membership before deploying; the bundled agent vLLM profiles require GPUs in the agent's own cluster.

</details>

<details>
<summary>Switch an existing agent to the new endpoint</summary>

For an existing installation, update only its provider settings, retaining enabled modules and site configuration. Use the same chart version already installed, or the explicitly selected upgrade version. `AGENT_CHART_VERSION` below must be set to that version; `AGENT_CHART` is the chart reference from the NMC guide.

First check the new endpoint from the existing agent pod, streaming the self-hosted key through stdin without changing its configuration:

```bash
printf '%s' "$EXTERNAL_LLM_API_KEY" | \
kubectl -n "${AGENT_NAMESPACE:?Set the existing agent namespace}" exec -i deployment/openclaw -c gateway -- \
  node --input-type=module -e '
let key = "";
for await (const chunk of process.stdin) key += chunk;
const response = await fetch(`${process.argv[1].replace(/\/$/, "")}/chat/completions`, {
  method: "POST",
  headers: {Authorization: `Bearer ${key}`, "Content-Type": "application/json"},
  body: JSON.stringify({model: process.argv[2], messages: [{role: "user", content: "Reply with ready."}], max_tokens: 32}),
  signal: AbortSignal.timeout(120000),
});
console.log(`Inference check: HTTP ${response.status}`);
if (!response.ok) process.exit(1);
' "$EXTERNAL_LLM_BASE_URL" "$EXTERNAL_LLM_MODEL"
```

Proceed after HTTP 200. Create a separate client Secret so the existing provider's Secret stays intact until the switch:

```bash
: "${AGENT_CHART_VERSION:?Set the intended chart version}"
: "${EXTERNAL_LLM_API_KEY:?Load the self-hosted key from your protected store}"
: "${AGENT_NAMESPACE:?Set the existing agent namespace}"
: "${AGENT_RELEASE:?Set the existing agent Helm release}"
: "${AGENT_CHART:?Set the existing agent chart reference}"
kubectl -n "$AGENT_NAMESPACE" create secret generic afoa-inference-client \
  --from-literal=apiKey="$EXTERNAL_LLM_API_KEY" \
  --dry-run=client -o yaml | kubectl apply -f -

helm upgrade "$AGENT_RELEASE" "$AGENT_CHART" \
  --version "$AGENT_CHART_VERSION" \
  -n "$AGENT_NAMESPACE" \
  --reuse-values \
  --set llm.mode=external \
  --set-string llm.external.baseUrl="$EXTERNAL_LLM_BASE_URL" \
  --set-string llm.external.model="$EXTERNAL_LLM_MODEL" \
  --set llm.external.existingSecret=afoa-inference-client \
  --set llm.external.apiKeySecretKey=apiKey \
  --wait \
  --timeout 12m

unset EXTERNAL_LLM_API_KEY
```

This changes the configured provider and restarts affected agent pods. Switching from bundled `llm.mode=vllm` also removes that release's bundled inference workload; verify the new endpoint first. The separate inference release and enabled agent modules remain independently managed. Rotating an existing Secret's key also requires restarting the consumers to reload their environment; updating only a Secret does not automatically restart pods.

</details>

<details>
<summary>Check startup and cross-cluster connectivity</summary>

Inspect inference startup in `k8s-user`:

```bash
module load kubernetes/k8s-user
kubectl -n afoa-inference get pods,pvc,service,ingress
kubectl -n afoa-inference describe pod afoa-inference-0
kubectl -n afoa-inference get events --sort-by=.lastTimestamp
kubectl -n afoa-inference logs afoa-inference-0 -c vllm --tail=100
```

`Pending` with insufficient resources indicates a scheduling problem; an unbound PVC indicates a storage problem. Downloads, model loading and first-start kernel compilation are expected. Resources remain available after a Helm timeout so you can inspect progress before retrying.

Switch back to the admin cluster for the connection check:

```bash
module load kubernetes/k8s-admin
```

After installing or switching, verify authenticated model discovery and a short completion from the actual agent pod. This uses the key already mounted into the pod without printing it:

```bash
kubectl -n "${AGENT_NAMESPACE:?Set the existing agent namespace}" exec -i deployment/openclaw -c gateway -- node --input-type=module - <<'JS'
const base = process.env.OPENCLAW_VLLM_BASE_URL.replace(/\/$/, '');
const headers = {
  Authorization: `Bearer ${process.env.VLLM_API_KEY}`,
  'Content-Type': 'application/json',
};
for (const [path, options] of [
  ['/models', {}],
  ['/chat/completions', {method: 'POST', body: JSON.stringify({
    model: 'nemotron-3.5-super-vl',
    messages: [{role: 'user', content: 'Reply with ready.'}],
    max_tokens: 32,
  })}],
]) {
  const response = await fetch(`${base}${path}`, {
    ...options, headers, signal: AbortSignal.timeout(120000),
  });
  console.log(`${path}: HTTP ${response.status}`);
  if (!response.ok) process.exit(1);
}
JS
```

Use your configured served model name in the completion check if you changed the default. HTTP 200 for both requests establishes DNS, routing, TLS trust, authentication, and basic inference from the admin cluster. Then ask a short question through the agent UI to verify the full agent path. TLS errors require correcting certificate trust, timeouts require checking routing or server readiness, and 401 responses indicate mismatched keys.

</details>


## Uninstall across both clusters

In the administrator login shell, confirm each release and namespace with `helm list -A`; use their existing names in the commands below. Remove the agent before its dedicated inference server, and keep shared inference running.

Back up required agent data first: Helm deletes its workspace and audit-log PVCs, and the storage reclaim policy determines whether backing data is deleted. If this release installed the AgentSandbox controller, confirm no other release depends on it. Keep shared CRDs and platform controllers.

### 1. Remove the agent from `k8s-admin`

```bash
module load kubernetes/k8s-admin
: "${AGENT_NAMESPACE:?Set the existing agent namespace}"
helm list -A
helm uninstall aifoa --namespace "$AGENT_NAMESPACE" --wait --timeout 12m
```

Separately created Secrets remain. Delete the namespace only if it is dedicated to this installation and all remaining resources and data can be discarded:

```bash
kubectl delete namespace "$AGENT_NAMESPACE"
```

Keep NMC's shared `net-pol` release. After the namespace has no remaining consumers, its policy owner can remove its entry from `admin.namespaceList` through the existing policy-management workflow.

### 2. Remove dedicated inference from `k8s-user`

Skip this section for existing or shared inference endpoints.

```bash
module load kubernetes/k8s-user
helm list -A
helm uninstall afoa-inference --namespace afoa-inference --wait --timeout 12m
```

The model-cache PVC and separately created API-key and TLS Secrets remain. Delete the namespace only if it is dedicated to this installation and its remaining data can be discarded; this deletes the PVC, with backing-storage deletion determined by its reclaim policy:

```bash
kubectl delete namespace afoa-inference
```
